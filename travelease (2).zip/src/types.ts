export interface Activity {
  title: string;
  time: string;
  duration: string;
  cost: number;
  location: string;
  description: string;
  completed?: boolean;
}

export interface DayPlan {
  dayNumber: number;
  theme: string;
  activities: Activity[];
}

export interface TripBudget {
  flights: number;
  lodging: number;
  food: number;
  activities: number;
  transport: number;
  misc: number;
}

export interface Expense {
  id: string;
  description: string;
  category: keyof TripBudget;
  amount: number;
  date: string;
}

export interface ChecklistItem {
  id: string;
  text: string;
  category: "packing" | "todo" | "documents";
  checked: boolean;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
}

export interface Trip {
  id: string;
  tripName: string;
  destination: string;
  description: string;
  bestSeason: string;
  daysCount: number;
  budgetLevel: "economy" | "mid-range" | "luxury";
  interests: string;
  travelerType: "solo" | "couple" | "family" | "friends";
  travelersCount: number;
  
  // Custom states that the user can mutate
  packingList: ChecklistItem[];
  budgetEstimate: TripBudget;
  actualExpenses: Expense[];
  itinerary: DayPlan[];
  
  createdAt: string;
  notes?: string;
}
