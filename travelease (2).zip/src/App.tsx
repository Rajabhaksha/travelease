import React, { useState, useEffect } from "react";
import { Compass, Calendar, ArrowLeft, RefreshCw, MessageSquare, ListTodo, DollarSign, Sparkles, MapPin } from "lucide-react";
import { Trip, DayPlan, TripBudget, Expense, ChecklistItem } from "./types";
import { SAMPLE_TRIPS } from "./data";
import Dashboard from "./components/Dashboard";
import TripPlannerForm from "./components/TripPlannerForm";
import TripItinerary from "./components/TripItinerary";
import BudgetTrackerView from "./components/BudgetTrackerView";
import ChecklistsView from "./components/ChecklistsView";
import AssistantChat from "./components/AssistantChat";

export default function App() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [activeTripId, setActiveTripId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"itinerary" | "budget" | "packing" | "chat">("itinerary");
  const [isPlanningNewTrip, setIsPlanningNewTrip] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load trips from LocalStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("travelease_trips");
      if (stored) {
        setTrips(JSON.parse(stored));
      } else {
        // Initialize with Kyoto sample if empty so they have an interactive workspace immediately
        setTrips(SAMPLE_TRIPS);
        localStorage.setItem("travelease_trips", JSON.stringify(SAMPLE_TRIPS));
      }
    } catch (e) {
      console.error("Failed to load local storage trips:", e);
      setTrips(SAMPLE_TRIPS);
    }
  }, []);

  // Helper to save trips to state & LocalStorage
  const updateAndStoreTrips = (updatedTrips: Trip[]) => {
    setTrips(updatedTrips);
    try {
      localStorage.setItem("travelease_trips", JSON.stringify(updatedTrips));
    } catch (e) {
      console.error("Failed to persist trips:", e);
    }
  };

  const handleSelectTrip = (tripId: string) => {
    setActiveTripId(tripId);
    setActiveTab("itinerary");
    setIsPlanningNewTrip(false);
    setError(null);
  };

  const handleDeleteTrip = (tripId: string) => {
    const filtered = trips.filter((t) => t.id !== tripId);
    updateAndStoreTrips(filtered);
    if (activeTripId === tripId) {
      setActiveTripId(null);
    }
  };

  const handleGenerateTrip = async (formData: {
    destination: string;
    days: number;
    budgetLevel: "economy" | "mid-range" | "luxury";
    travelerType: "solo" | "couple" | "family" | "friends";
    travelersCount: number;
    interests: string;
  }) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/itinerary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "An error occurred while generating your itinerary.");
      }

      const generatedData = await response.json();

      // Transform raw packingList strings into object shapes
      const formattedPacking: ChecklistItem[] = (generatedData.packingList || []).map((itemStr: string, index: number) => ({
        id: `pack-${Date.now()}-${index}`,
        text: itemStr,
        category: itemStr.toLowerCase().includes("passport") || itemStr.toLowerCase().includes("ticket") || itemStr.toLowerCase().includes("insurance") || itemStr.toLowerCase().includes("visa")
          ? "documents"
          : "packing",
        checked: false,
      }));

      // Append standard helpful preparation items
      formattedPacking.push(
        { id: `pack-${Date.now()}-essential-1`, text: "Check passport expiration (must be 6 months valid)", category: "documents", checked: false },
        { id: `pack-${Date.now()}-essential-2`, text: "Notify credit card company of international travel", category: "todo", checked: false },
        { id: `pack-${Date.now()}-essential-3`, text: "Arrange airport transfers", category: "todo", checked: false }
      );

      const newTrip: Trip = {
        id: `trip-${Date.now()}`,
        tripName: generatedData.tripName || `My Adventure in ${formData.destination}`,
        destination: generatedData.destination || formData.destination,
        description: generatedData.description || "Exciting adventure curated by TravelEase.",
        bestSeason: generatedData.bestSeason || "Year-round",
        daysCount: formData.days,
        budgetLevel: formData.budgetLevel,
        interests: formData.interests,
        travelerType: formData.travelerType,
        travelersCount: formData.travelersCount,
        packingList: formattedPacking,
        budgetEstimate: generatedData.budgetEstimate || {
          flights: 800,
          lodging: 600,
          food: 400,
          activities: 300,
          transport: 150,
          misc: 150
        },
        actualExpenses: [],
        itinerary: generatedData.itinerary || [],
        createdAt: new Date().toISOString(),
      };

      const updatedList = [newTrip, ...trips];
      updateAndStoreTrips(updatedList);
      setActiveTripId(newTrip.id);
      setIsPlanningNewTrip(false);
      setActiveTab("itinerary");
    } catch (err: any) {
      console.error("Generation Error:", err);
      setError(err.message || "Failed to generate your trip itinerary. Please check your connection or try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const activeTrip = trips.find((t) => t.id === activeTripId) || null;

  // Setters inside active trip
  const handleUpdateItinerary = (updatedItinerary: DayPlan[]) => {
    if (!activeTripId) return;
    const updated = trips.map((t) => {
      if (t.id === activeTripId) {
        return { ...t, itinerary: updatedItinerary };
      }
      return t;
    });
    updateAndStoreTrips(updated);
  };

  const handleUpdateNotes = (notes: string) => {
    if (!activeTripId) return;
    const updated = trips.map((t) => {
      if (t.id === activeTripId) {
        return { ...t, notes };
      }
      return t;
    });
    updateAndStoreTrips(updated);
  };

  const handleUpdateBudget = (updatedBudget: TripBudget) => {
    if (!activeTripId) return;
    const updated = trips.map((t) => {
      if (t.id === activeTripId) {
        return { ...t, budgetEstimate: updatedBudget };
      }
      return t;
    });
    updateAndStoreTrips(updated);
  };

  const handleUpdateExpenses = (updatedExpenses: Expense[]) => {
    if (!activeTripId) return;
    const updated = trips.map((t) => {
      if (t.id === activeTripId) {
        return { ...t, actualExpenses: updatedExpenses };
      }
      return t;
    });
    updateAndStoreTrips(updated);
  };

  const handleUpdateChecklist = (updatedList: ChecklistItem[]) => {
    if (!activeTripId) return;
    const updated = trips.map((t) => {
      if (t.id === activeTripId) {
        return { ...t, packingList: updatedList };
      }
      return t;
    });
    updateAndStoreTrips(updated);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Top Premium Navbar */}
      <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-100 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div 
            onClick={() => {
              setActiveTripId(null);
              setIsPlanningNewTrip(false);
            }} 
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-sm shadow-blue-500/10 group-hover:scale-105 transition-transform">
              <Compass className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-lg text-slate-900 tracking-tight">
              Travel<span className="text-blue-600">Ease</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {activeTripId && (
              <button
                onClick={() => setActiveTripId(null)}
                className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 bg-slate-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Trips Dashboard
              </button>
            )}
            <span className="text-[10px] sm:text-xs text-slate-400 font-mono bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-full flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
              AI Assistant Ready
            </span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Loading overlay during AI generation */}
        {isLoading && (
          <div className="bg-white border border-slate-100 rounded-2xl p-8 md:p-12 text-center shadow-sm space-y-6 max-w-xl mx-auto my-12">
            <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin" />
              <Compass className="w-6 h-6 text-blue-600 animate-pulse" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-display font-semibold text-slate-950 flex items-center justify-center gap-1.5">
                <Sparkles className="w-5 h-5 text-amber-500 animate-bounce" />
                Mapping Your Travel Experience
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                Gemini is exploring places, projecting lodging costs, scheduling museum visits, and compiling your checklist based on climate profiles...
              </p>
            </div>
            {/* Ambient progress tracker messages */}
            <div className="text-xs text-slate-400 font-mono py-1.5 bg-slate-50 rounded-lg max-w-xs mx-auto">
              Curating high-fidelity itineraries...
            </div>
          </div>
        )}

        {/* Error Notification Banner */}
        {error && !isLoading && (
          <div className="bg-red-50 border border-red-100 rounded-2xl p-5 text-sm text-red-800 max-w-xl mx-auto my-8 space-y-3 shadow-sm">
            <div className="font-semibold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-600" />
              Curator Encountered An Issue
            </div>
            <p className="text-xs sm:text-sm text-red-700 leading-relaxed">{error}</p>
            <div className="pt-2">
              <button
                onClick={() => setError(null)}
                className="px-4 py-1.5 bg-red-100 hover:bg-red-200 text-red-900 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                Acknowledge
              </button>
            </div>
          </div>
        )}

        {/* Normal Views */}
        {!isLoading && (
          <>
            {isPlanningNewTrip ? (
              <div className="max-w-3xl mx-auto space-y-4">
                <button
                  onClick={() => setIsPlanningNewTrip(false)}
                  className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 bg-white border border-slate-200 px-3 py-1.5 rounded-lg cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back to Dashboard
                </button>
                <TripPlannerForm onGenerate={handleGenerateTrip} isLoading={isLoading} />
              </div>
            ) : activeTrip ? (
              <div className="space-y-6">
                {/* Active Trip Header */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
                  <div className="space-y-2">
                    <button
                      onClick={() => setActiveTripId(null)}
                      className="flex items-center gap-1 text-xs text-slate-400 hover:text-blue-600 font-semibold transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      Back to Dashboard
                    </button>
                    <div className="space-y-1">
                      <h2 className="text-2xl font-display font-bold text-slate-900 leading-snug">
                        {activeTrip.tripName}
                      </h2>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-500 font-semibold">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          {activeTrip.destination}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {activeTrip.daysCount} Days
                        </span>
                        <span className="capitalize px-2 py-0.5 bg-slate-100 text-slate-600 rounded">
                          {activeTrip.budgetLevel} budget
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Desktop navigation back button */}
                  <button
                    onClick={() => setActiveTripId(null)}
                    className="sm:hidden px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                  >
                    All Trips
                  </button>
                </div>

                {/* Sub Tab Controls */}
                <div className="flex border-b border-slate-200 overflow-x-auto pb-0.5 scrollbar-none">
                  {[
                    { id: "itinerary", label: "Itinerary Timeline", icon: <Calendar className="w-4 h-4" /> },
                    { id: "budget", label: "Budget Tracker", icon: <DollarSign className="w-4 h-4" /> },
                    { id: "packing", label: "Checklists & Packing", icon: <ListTodo className="w-4 h-4" /> },
                    { id: "chat", label: "AI Local Guide", icon: <MessageSquare className="w-4 h-4" /> },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-1.5 px-5 py-3 border-b-2 text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                        activeTab === tab.id
                          ? "border-blue-600 text-blue-600"
                          : "border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300"
                      }`}
                    >
                      {tab.icon}
                      {tab.label}
                    </button>
                  ))}
                </div>

                {/* Sub Tab Components */}
                <div className="transition-all duration-150">
                  {activeTab === "itinerary" && (
                    <TripItinerary
                      trip={activeTrip}
                      onUpdateItinerary={handleUpdateItinerary}
                      onUpdateNotes={handleUpdateNotes}
                    />
                  )}
                  {activeTab === "budget" && (
                    <BudgetTrackerView
                      trip={activeTrip}
                      onUpdateBudget={handleUpdateBudget}
                      onUpdateExpenses={handleUpdateExpenses}
                    />
                  )}
                  {activeTab === "packing" && (
                    <ChecklistsView
                      packingList={activeTrip.packingList}
                      onUpdateChecklist={handleUpdateChecklist}
                    />
                  )}
                  {activeTab === "chat" && <AssistantChat trip={activeTrip} />}
                </div>
              </div>
            ) : (
              <Dashboard
                trips={trips}
                onSelectTrip={handleSelectTrip}
                onDeleteTrip={handleDeleteTrip}
                onStartNewTrip={() => setIsPlanningNewTrip(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 py-6 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-1.5 text-xs text-slate-400">
          <p className="font-semibold text-slate-500">TravelEase • Your Smart Travel Management Hub</p>
          <p>© 2026 TravelEase. Created with Google Gemini 3.5 models. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
