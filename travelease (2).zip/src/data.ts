import { Trip } from "./types";

export const SAMPLE_TRIPS: Trip[] = [
  {
    id: "sample-kyoto",
    tripName: "Kyoto Zen Gardens & Tea Traditions",
    destination: "Kyoto, Japan",
    description: "Immerse yourself in the ancient capital of Japan. Discover cobblestone streets of Gion, iconic red torii gates of Fushimi Inari, serene bamboo groves of Arashiyama, and participate in authentic green tea ceremonies.",
    bestSeason: "Autumn (October - November) or Cherry Blossom Season (April)",
    daysCount: 4,
    budgetLevel: "mid-range",
    interests: "history, culture, local food, gardens",
    travelerType: "couple",
    travelersCount: 2,
    createdAt: new Date().toISOString(),
    notes: "Remember to purchase the ICOCA card for local transport. Check restaurant reservations in Gion ahead of time.",
    packingList: [
      { id: "p1", text: "Comfortable walking shoes (essential for temple stairs)", category: "packing", checked: true },
      { id: "p2", text: "Slip-on shoes for easy removal at temple entrances", category: "packing", checked: false },
      { id: "p3", text: "Pocket Wi-Fi or eSIM QR code", category: "packing", checked: true },
      { id: "p4", text: "Cash (Yen) - many small shrines and street food stalls only accept cash", category: "packing", checked: false },
      { id: "p5", text: "Universal travel adapter (Type A/B)", category: "packing", checked: true },
      { id: "p6", text: "Light jacket or cardigan for evening temple light-ups", category: "packing", checked: false },
      { id: "p7", text: "Passport & flight confirmation", category: "documents", checked: true },
      { id: "p8", text: "Travel insurance printout", category: "documents", checked: true },
      { id: "p9", text: "Book Gion Dinner Experience", category: "todo", checked: true },
      { id: "p10", text: "Download Google Translate offline dictionary", category: "todo", checked: false }
    ],
    budgetEstimate: {
      flights: 850,
      lodging: 480,
      food: 350,
      activities: 120,
      transport: 90,
      misc: 150
    },
    actualExpenses: [
      { id: "e1", description: "Bullet Train (Tokyo to Kyoto)", category: "transport", amount: 130, date: "2026-07-01" },
      { id: "e2", description: "Machiya Townhouse Hotel", category: "lodging", amount: 450, date: "2026-07-02" },
      { id: "e3", description: "Kaiseki Dinner in Gion", category: "food", amount: 180, date: "2026-07-02" },
      { id: "e4", description: "Tea Ceremony Workshop", category: "activities", amount: 80, date: "2026-07-03" },
      { id: "e5", description: "Daily Bus & Subway Pass", category: "transport", amount: 15, date: "2026-07-03" }
    ],
    itinerary: [
      {
        dayNumber: 1,
        theme: "Arashiyama & Golden Pavilion",
        activities: [
          {
            title: "Arashiyama Bamboo Grove",
            time: "07:30 AM",
            duration: "2 hours",
            cost: 0,
            location: "Arashiyama, Ukyo Ward",
            description: "Walk through the soaring bamboo pathways early in the morning before crowds arrive. The sound of wind rustling through the stalks is a government-designated soundscape of Japan."
          },
          {
            title: "Tenryu-ji Temple",
            time: "09:45 AM",
            duration: "1.5 hours",
            cost: 8,
            location: "Right outside the Bamboo Grove entrance",
            description: "Explore one of Kyoto's premier Zen temples, featuring an exquisite 14th-century garden that has survived fires and retains its original form with reflection ponds and mountains."
          },
          {
            title: "Lunch: Yudofu (Tofu Hotpot)",
            time: "12:00 PM",
            duration: "1 hour",
            cost: 25,
            location: "Saga tofu Ine, Arashiyama",
            description: "Enjoy traditional vegetarian Buddhist cuisine featuring freshly prepared silken tofu, sesame tofu, and seasonal vegetable tempura overlooking a garden."
          },
          {
            title: "Kinkaku-ji (The Golden Pavilion)",
            time: "02:00 PM",
            duration: "1.5 hours",
            cost: 5,
            location: "1 Kinkakujicho, Kita Ward",
            description: "Admire the breathtaking Zen temple whose top two floors are completely covered in brilliant gold leaf, casting a perfect reflection across the Mirror Pond."
          },
          {
            title: "Traditional Tea Ceremony Experience",
            time: "04:30 PM",
            duration: "1.5 hours",
            cost: 40,
            location: "Camellia Tea House, near Kinkaku-ji",
            description: "Learn the Zen philosophy behind Japanese tea preparation. Whisk your own bowl of high-quality Uji matcha guided by a licensed master."
          }
        ]
      },
      {
        dayNumber: 2,
        theme: "Historic Higashiyama & Gion Streets",
        activities: [
          {
            title: "Kiyomizu-dera Temple",
            time: "08:00 AM",
            duration: "2 hours",
            cost: 4,
            location: "1-294 Kiyomizu, Higashiyama Ward",
            description: "Stand on the massive wooden stage built entirely without nails. The stage hangs over the hillside, offering panoramic views of Kyoto framed by cherry blossoms or maple trees."
          },
          {
            title: "Sannenzaka & Ninenzaka Streets",
            time: "10:15 AM",
            duration: "1.5 hours",
            cost: 0,
            location: "Higashiyama historic preserved district",
            description: "Stroll down steep, flagstone paved streets lined with beautifully preserved wooden merchant homes, traditional shops, and sweet vendors."
          },
          {
            title: "Gion District & Evening Hanami-koji Stroll",
            time: "05:00 PM",
            duration: "3 hours",
            cost: 90,
            location: "Gion, Kyoto",
            description: "Wander around the lantern-lit wooden buildings of Kyoto's most famous geisha district. Have a reservation for a classic multi-course Kaiseki dinner."
          }
        ]
      }
    ]
  }
];
