import React, { useState } from "react";
import { DollarSign, Plus, Trash2, PieChart, Info, Calendar } from "lucide-react";
import { Trip, Expense, TripBudget } from "../types";

interface BudgetTrackerViewProps {
  trip: Trip;
  onUpdateBudget: (updatedBudget: TripBudget) => void;
  onUpdateExpenses: (updatedExpenses: Expense[]) => void;
}

export default function BudgetTrackerView({ trip, onUpdateBudget, onUpdateExpenses }: BudgetTrackerViewProps) {
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState(0);
  const [category, setCategory] = useState<keyof TripBudget>("food");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [editedBudget, setEditedBudget] = useState<TripBudget>({ ...trip.budgetEstimate });

  const categories: { key: keyof TripBudget; label: string; color: string; bg: string; text: string }[] = [
    { key: "flights", label: "Flights & Transit", color: "bg-blue-500", bg: "bg-blue-50", text: "text-blue-700" },
    { key: "lodging", label: "Hotels & Lodging", color: "bg-indigo-500", bg: "bg-indigo-50", text: "text-indigo-700" },
    { key: "food", label: "Food & Dining", color: "bg-amber-500", bg: "bg-amber-50", text: "text-amber-700" },
    { key: "activities", label: "Activities & Tours", color: "bg-emerald-500", bg: "bg-emerald-50", text: "text-emerald-700" },
    { key: "transport", label: "Local Transport", color: "bg-purple-500", bg: "bg-purple-50", text: "text-purple-700" },
    { key: "misc", label: "Souvenirs & Misc", color: "bg-slate-500", bg: "bg-slate-50", text: "text-slate-700" },
  ];

  // Calculations
  const getCategoryEstimate = (cat: keyof TripBudget) => trip.budgetEstimate[cat] || 0;

  const getCategoryActual = (cat: keyof TripBudget) => {
    return trip.actualExpenses
      .filter((e) => e.category === cat)
      .reduce((sum, e) => sum + e.amount, 0);
  };

  const totalEstimate = Object.values(trip.budgetEstimate).reduce((sum, val) => sum + val, 0);
  const totalActual = trip.actualExpenses.reduce((sum, e) => sum + e.amount, 0);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc.trim() || amount <= 0) return;

    const newExpense: Expense = {
      id: Math.random().toString(36).substring(2, 9),
      description: desc,
      category,
      amount: Number(amount),
      date: date || new Date().toISOString().split("T")[0],
    };

    onUpdateExpenses([...trip.actualExpenses, newExpense]);
    setDesc("");
    setAmount(0);
  };

  const handleDeleteExpense = (id: string) => {
    onUpdateExpenses(trip.actualExpenses.filter((e) => e.id !== id));
  };

  const handleSaveBudgetEdit = () => {
    onUpdateBudget(editedBudget);
    setIsEditingBudget(false);
  };

  return (
    <div className="space-y-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Projected Budget</span>
            <p className="text-3xl font-display font-bold text-slate-950">${totalEstimate.toLocaleString()}</p>
          </div>
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
            <PieChart className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Logged Expenses</span>
            <p className="text-3xl font-display font-bold text-slate-950">${totalActual.toLocaleString()}</p>
          </div>
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${totalActual > totalEstimate ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-600"}`}>
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Remaining Budget</span>
            <p className={`text-3xl font-display font-bold ${totalEstimate - totalActual >= 0 ? "text-slate-900" : "text-red-600"}`}>
              ${(totalEstimate - totalActual).toLocaleString()}
            </p>
          </div>
          <div className="text-xs font-medium bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-100">
            {totalActual === 0 ? "0%" : `${Math.round((totalActual / totalEstimate) * 100)}%`} used
          </div>
        </div>
      </div>

      {/* Main Budget layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Comparison Bars */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-display font-semibold text-slate-950">
                Budget Allocation Breakdown
              </h3>
              <p className="text-xs text-slate-400">Projected (gray background) vs. Actual Spending (colored indicators)</p>
            </div>
            <button
              onClick={() => {
                setEditedBudget({ ...trip.budgetEstimate });
                setIsEditingBudget(!isEditingBudget);
              }}
              className="text-sm font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 px-3 py-1.5 rounded-lg"
            >
              {isEditingBudget ? "Cancel" : "Adjust Targets"}
            </button>
          </div>

          {isEditingBudget ? (
            <div className="space-y-4 p-4 bg-slate-50 rounded-xl border border-slate-200/60">
              <h4 className="text-sm font-semibold text-slate-800 mb-2">Configure Target Budgets ($ USD)</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {categories.map((c) => (
                  <div key={c.key} className="space-y-1">
                    <label className="text-xs font-medium text-slate-500 capitalize">{c.label}</label>
                    <input
                      type="number"
                      value={editedBudget[c.key]}
                      onChange={(e) => setEditedBudget({ ...editedBudget, [c.key]: Number(e.target.value) })}
                      className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 bg-white focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                ))}
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={handleSaveBudgetEdit}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm"
                >
                  Save Changes
                </button>
              </div>
            </div>
          ) : null}

          {/* Category Progress Bars */}
          <div className="space-y-5">
            {categories.map((cat) => {
              const estimate = getCategoryEstimate(cat.key);
              const actual = getCategoryActual(cat.key);
              const percentage = estimate > 0 ? Math.min((actual / estimate) * 100, 100) : actual > 0 ? 100 : 0;
              const overspent = actual > estimate;

              return (
                <div key={cat.key} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs sm:text-sm">
                    <span className="font-semibold text-slate-700 capitalize flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                      {cat.label}
                    </span>
                    <div className="space-x-1">
                      <span className="font-semibold text-slate-900">${actual.toLocaleString()}</span>
                      <span className="text-slate-400">/ ${estimate.toLocaleString()}</span>
                      {overspent && (
                        <span className="text-xs text-red-600 bg-red-50 font-bold px-1.5 py-0.5 rounded ml-1">
                          +${(actual - estimate).toLocaleString()} Over
                        </span>
                      )}
                    </div>
                  </div>
                  {/* Custom progress bar */}
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden relative">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        overspent ? "bg-red-500" : cat.color
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Log Expense Form */}
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2.5">
              Log Quick Expense
            </h3>
            <form onSubmit={handleAddExpense} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="font-medium text-slate-600">Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Michelin Dinner, Taxi to Castle"
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50/35 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-medium text-slate-600">Amount ($)</label>
                  <input
                    type="number"
                    required
                    placeholder="25.50"
                    value={amount || ""}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50/35 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-medium text-slate-600">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50/35 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-medium text-slate-600">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50/35 focus:outline-none focus:ring-1 focus:ring-blue-500 capitalize"
                >
                  {categories.map((c) => (
                    <option key={c.key} value={c.key}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={!desc.trim() || amount <= 0}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                Add Receipt
              </button>
            </form>
          </div>
          
          <div className="mt-4 p-3 bg-blue-50/30 rounded-xl border border-blue-100/40 text-xs text-blue-700 flex gap-2">
            <Info className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
            <span>Actual expenditures logged here will directly subtract from your remaining spending pool.</span>
          </div>
        </div>
      </div>

      {/* Transaction History Registry */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
        <h3 className="text-lg font-display font-semibold text-slate-950 border-b border-slate-100 pb-4 mb-4">
          Expense Transaction History
        </h3>

        {trip.actualExpenses.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-sm text-slate-400">No expenses logged yet. Create your first expense above!</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Description</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4 text-center w-20">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {trip.actualExpenses.map((exp) => {
                  const catConfig = categories.find((c) => c.key === exp.category);
                  return (
                    <tr key={exp.id} className="hover:bg-slate-50/40 transition-colors">
                      <td className="py-3 px-4 text-slate-500 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {exp.date}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-800">{exp.description}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider ${catConfig?.bg} ${catConfig?.text}`}>
                          {catConfig?.label}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">${exp.amount.toFixed(2)}</td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleDeleteExpense(exp.id)}
                          className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
