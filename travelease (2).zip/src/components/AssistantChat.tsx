import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, User, HelpCircle, AlertCircle, Compass } from "lucide-react";
import { Trip, ChatMessage } from "../types";

interface AssistantChatProps {
  trip: Trip;
}

export default function AssistantChat({ trip }: AssistantChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "assistant",
      text: `Hi there! I am your personal **TravelEase Local Expert** for **${trip.destination}**. 

I have full access to your planned itinerary and budget targets. How can I help you customize your trip today? You can ask me:
- *What are some authentic local restaurants or street food specialties in ${trip.destination.split(",")[0]}?*
- *Can you recommend some hidden gems or spots that tourists usually miss?*
- *What are the essential cultural etiquettes and customs I should know?*
- *Give me a 3-sentence packing checklist for the local climate.*`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(36).substring(2, 9),
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          destination: trip.destination,
          tripContext: {
            tripName: trip.tripName,
            budgetLevel: trip.budgetLevel,
            interests: trip.interests,
            daysCount: trip.daysCount,
            itinerarySummary: trip.itinerary.map(day => `Day ${day.dayNumber}: ${day.theme} (${day.activities.length} activities)`).join(", ")
          },
          chatHistory: messages.slice(-6) // Send recent history for context
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to contact travel assistant.");
      }

      const data = await response.json();
      
      const assistantMsg: ChatMessage = {
        id: Math.random().toString(36).substring(2, 9),
        sender: "assistant",
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error("Chat Error:", err);
      setError(err.message || "Could not connect to travel assistant. Please check your network connection.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(input);
  };

  const suggestedQuestions = [
    { text: "Food specialties & dining spots", icon: <Compass className="w-3.5 h-3.5" /> },
    { text: "Local customs & greeting etiquette", icon: <Sparkles className="w-3.5 h-3.5 text-amber-500" /> },
    { text: "Rainy day backups or indoor spots", icon: <HelpCircle className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col h-[650px] overflow-hidden">
      {/* Header */}
      <div className="bg-slate-50 border-b border-slate-100 p-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-display font-semibold text-slate-900 text-sm">
              Local Expert Guide
            </h3>
            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Connected • Powered by Gemini AI
            </span>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-grow overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/20">
        {messages.map((msg) => {
          const isAssistant = msg.sender === "assistant";
          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-[85%] ${
                isAssistant ? "mr-auto" : "ml-auto flex-row-reverse"
              }`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
                  isAssistant ? "bg-blue-100 text-blue-600" : "bg-slate-200 text-slate-700"
                }`}
              >
                {isAssistant ? <Sparkles className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              {/* Message Body */}
              <div className="space-y-1">
                <div
                  className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    isAssistant
                      ? "bg-white text-slate-800 border border-slate-100 shadow-sm"
                      : "bg-blue-600 text-white"
                  }`}
                >
                  <div className="whitespace-pre-wrap select-text markdown-body">
                    {/* Render basic markdown since react-markdown removes class and has complexity */}
                    {/* Simplified manual parsing for key items like bullets, bold, italics */}
                    {msg.text.split("\n").map((line, idx) => {
                      let processedLine = line;
                      // Handle Bullet list
                      const isBullet = line.trim().startsWith("- ") || line.trim().startsWith("* ");
                      if (isBullet) {
                        processedLine = line.trim().substring(2);
                      }
                      
                      // Handle bold markdown (simple string replace for display)
                      const parts = processedLine.split("**");
                      const renderedParts = parts.map((part, pIdx) => {
                        if (pIdx % 2 === 1) {
                          return <strong key={pIdx} className="font-bold">{part}</strong>;
                        }
                        // Handle italics
                        const iParts = part.split("*");
                        return iParts.map((ipart, iIdx) => {
                          if (iIdx % 2 === 1) {
                            return <em key={iIdx} className="italic">{ipart}</em>;
                          }
                          return ipart;
                        });
                      });

                      if (isBullet) {
                        return (
                          <li key={idx} className="list-disc ml-4 my-1">
                            {renderedParts}
                          </li>
                        );
                      }
                      return <p key={idx} className={line === "" ? "h-3" : "my-1.5"}>{renderedParts}</p>;
                    })}
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 block px-1">
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}

        {/* Loading Bubble */}
        {isLoading && (
          <div className="flex gap-3 max-w-[85%] mr-auto animate-pulse">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="space-y-1">
              <div className="bg-white rounded-2xl px-4 py-3 border border-slate-100 shadow-sm flex items-center gap-1.5">
                <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}

        {/* Errors */}
        {error && (
          <div className="bg-red-50 border border-red-100 rounded-xl p-3.5 text-xs text-red-800 flex gap-2 max-w-[90%] mx-auto items-start">
            <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold">Assistant Connection Failed</span>
              <p className="mt-1">{error}</p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions Area */}
      <div className="bg-slate-50 border-t border-slate-100 p-3 flex flex-wrap gap-2 items-center">
        <span className="text-[11px] text-slate-400 font-semibold px-1">Ask about:</span>
        {suggestedQuestions.map((q, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleSendMessage(`Tell me about: ${q.text} in ${trip.destination}`)}
            disabled={isLoading}
            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-white border border-slate-200 hover:border-slate-300 rounded-lg text-slate-600 transition-all cursor-pointer disabled:opacity-50"
          >
            {q.icon}
            {q.text}
          </button>
        ))}
      </div>

      {/* Form Input */}
      <form onSubmit={handleFormSubmit} className="p-3 bg-white border-t border-slate-150 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isLoading}
          placeholder={`Ask about transport, restaurants, or sights in ${trip.destination.split(",")[0]}...`}
          className="flex-grow px-4 py-2.5 text-sm rounded-xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 disabled:opacity-60 transition-all"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl px-4 py-2.5 flex items-center justify-center transition-all shadow-sm cursor-pointer disabled:opacity-50 flex-shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
