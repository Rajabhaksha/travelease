import React, { useState } from "react";
import { ChecklistItem } from "../types";
import { CheckSquare, Square, Plus, Trash2, ShieldAlert, CheckCircle2 } from "lucide-react";

interface ChecklistsViewProps {
  packingList: ChecklistItem[];
  onUpdateChecklist: (updatedList: ChecklistItem[]) => void;
}

export default function ChecklistsView({ packingList, onUpdateChecklist }: ChecklistsViewProps) {
  const [newItemText, setNewItemText] = useState("");
  const [newItemCategory, setNewItemCategory] = useState<"packing" | "todo" | "documents">("packing");

  const categories = [
    { key: "documents", label: "Documents & Essentials", color: "bg-blue-600", text: "text-blue-600", border: "border-blue-100", bg: "bg-blue-50/20" },
    { key: "packing", label: "Luggage & Packing", color: "bg-emerald-600", text: "text-emerald-600", border: "border-emerald-100", bg: "bg-emerald-50/20" },
    { key: "todo", label: "Pre-trip To-Do List", color: "bg-amber-600", text: "text-amber-600", border: "border-amber-100", bg: "bg-amber-50/20" },
  ];

  const handleToggleItem = (itemId: string) => {
    const updated = packingList.map((item) => {
      if (item.id === itemId) {
        return { ...item, checked: !item.checked };
      }
      return item;
    });
    onUpdateChecklist(updated);
  };

  const handleDeleteItem = (itemId: string) => {
    onUpdateChecklist(packingList.filter((item) => item.id !== itemId));
  };

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemText.trim()) return;

    const newItem: ChecklistItem = {
      id: Math.random().toString(36).substring(2, 9),
      text: newItemText.trim(),
      category: newItemCategory,
      checked: false,
    };

    onUpdateChecklist([...packingList, newItem]);
    setNewItemText("");
  };

  // Completion metrics
  const getCategoryMetrics = (catKey: "packing" | "todo" | "documents") => {
    const items = packingList.filter((item) => item.category === catKey);
    const total = items.length;
    const checked = items.filter((item) => item.checked).length;
    return { total, checked, percentage: total > 0 ? Math.round((checked / total) * 100) : 0 };
  };

  return (
    <div className="space-y-8">
      {/* Metrics Summary banner */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
        <h3 className="text-lg font-display font-semibold text-slate-950 mb-4 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-blue-600" />
          Preparation Checklist & Packing Status
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat) => {
            const metrics = getCategoryMetrics(cat.key as any);
            return (
              <div key={cat.key} className="space-y-2 p-4 rounded-xl border border-slate-100 bg-slate-50/50">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-600">{cat.label}</span>
                  <span className="font-bold text-slate-900">{metrics.checked}/{metrics.total} packed</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${cat.color}`}
                    style={{ width: `${metrics.percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Checklist Board */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-1 gap-6">
            {categories.map((cat) => {
              const catItems = packingList.filter((item) => item.category === cat.key);
              return (
                <div key={cat.key} className={`bg-white rounded-2xl border ${cat.border} p-6 shadow-sm space-y-4`}>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h3 className={`text-base font-display font-semibold ${cat.text}`}>
                      {cat.label}
                    </h3>
                    <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
                      {catItems.filter((i) => i.checked).length} of {catItems.length}
                    </span>
                  </div>

                  <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                    {catItems.length === 0 ? (
                      <p className="text-sm text-slate-400 py-4 text-center">No items added to this category.</p>
                    ) : (
                      catItems.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => handleToggleItem(item.id)}
                          className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group border border-slate-50 hover:border-slate-100"
                        >
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              className="text-slate-400 group-hover:text-blue-600 transition-colors"
                            >
                              {item.checked ? (
                                <CheckSquare className="w-5 h-5 text-blue-600 fill-blue-50" />
                              ) : (
                                <Square className="w-5 h-5" />
                              )}
                            </button>
                            <span className={`text-sm text-slate-700 ${item.checked ? "line-through text-slate-400" : ""}`}>
                              {item.text}
                            </span>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteItem(item.id);
                            }}
                            className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Add Checklist Item Form */}
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between h-fit space-y-6">
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2.5">
              Add Item to Checklist
            </h3>
            <form onSubmit={handleAddItem} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="font-medium text-slate-600">Item Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Umbrella, Powerbank, Print flight tickets"
                  value={newItemText}
                  onChange={(e) => setNewItemText(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-slate-50/35 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="font-medium text-slate-600">Category Selection</label>
                <div className="flex flex-col gap-2">
                  {categories.map((c) => (
                    <button
                      key={c.key}
                      type="button"
                      onClick={() => setNewItemCategory(c.key as any)}
                      className={`py-2 px-3 rounded-lg border text-xs font-semibold text-left transition-all ${
                        newItemCategory === c.key
                          ? "bg-blue-50 border-blue-200 text-blue-700 font-bold"
                          : "bg-slate-50 border-slate-150 text-slate-600 hover:bg-slate-100"
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={!newItemText.trim()}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer disabled:opacity-50 text-sm"
              >
                <Plus className="w-4 h-4" />
                Add Checklist Item
              </button>
            </form>
          </div>

          <div className="p-3 bg-amber-50/40 rounded-xl border border-amber-100/50 text-xs text-amber-800 flex gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <span>Double check visa requirements and passport expiration dates (must be at least 6 months valid) before finalizing documents!</span>
          </div>
        </div>
      </div>
    </div>
  );
}
