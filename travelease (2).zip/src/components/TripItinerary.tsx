import React, { useState } from "react";
import { Clock, MapPin, DollarSign, Plus, Trash2, CheckCircle2, Circle, ChevronDown, ChevronUp, FileText } from "lucide-react";
import { Activity, DayPlan, Trip } from "../types";

interface TripItineraryProps {
  trip: Trip;
  onUpdateItinerary: (updatedItinerary: DayPlan[]) => void;
  onUpdateNotes: (notes: string) => void;
}

export default function TripItinerary({ trip, onUpdateItinerary, onUpdateNotes }: TripItineraryProps) {
  const [activeDayIndex, setActiveDayIndex] = useState(0);
  const [showAddForm, setShowAddForm] = useState(false);
  const [expandedActivityIndex, setExpandedActivityIndex] = useState<number | null>(0);

  // Form fields for a new custom activity
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("");
  const [newDuration, setNewDuration] = useState("");
  const [newCost, setNewCost] = useState(0);
  const [newLocation, setNewLocation] = useState("");
  const [newDescription, setNewDescription] = useState("");

  const currentDay = trip.itinerary[activeDayIndex] || { dayNumber: 1, theme: "N/A", activities: [] };

  const handleToggleActivity = (activityIndex: number) => {
    const updated = [...trip.itinerary];
    const day = { ...updated[activeDayIndex] };
    const activities = [...day.activities];
    const act = { ...activities[activityIndex] };
    
    act.completed = !act.completed;
    activities[activityIndex] = act;
    day.activities = activities;
    updated[activeDayIndex] = day;
    onUpdateItinerary(updated);
  };

  const handleDeleteActivity = (activityIndex: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm("Are you sure you want to delete this activity?")) return;
    
    const updated = [...trip.itinerary];
    const day = { ...updated[activeDayIndex] };
    day.activities = day.activities.filter((_, idx) => idx !== activityIndex);
    updated[activeDayIndex] = day;
    onUpdateItinerary(updated);
    
    if (expandedActivityIndex === activityIndex) {
      setExpandedActivityIndex(null);
    }
  };

  const handleAddActivitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newActivity: Activity = {
      title: newTitle,
      time: newTime || "Anytime",
      duration: newDuration || "1 hour",
      cost: Number(newCost) || 0,
      location: newLocation || "N/A",
      description: newDescription || "No description provided.",
      completed: false,
    };

    const updated = [...trip.itinerary];
    const day = { ...updated[activeDayIndex] };
    day.activities = [...day.activities, newActivity];
    // Sort activities by time if possible (simplified approach, just append)
    updated[activeDayIndex] = day;
    onUpdateItinerary(updated);

    // Reset form
    setNewTitle("");
    setNewTime("");
    setNewDuration("");
    setNewCost(0);
    setNewLocation("");
    setNewDescription("");
    setShowAddForm(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Timeline and Days */}
      <div className="lg:col-span-2 space-y-6">
        {/* Day Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {trip.itinerary.map((dayPlan, idx) => (
            <button
              key={idx}
              onClick={() => {
                setActiveDayIndex(idx);
                setExpandedActivityIndex(0);
              }}
              className={`flex-shrink-0 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                activeDayIndex === idx
                  ? "bg-blue-600 text-white shadow-sm shadow-blue-500/10"
                  : "bg-white border border-slate-100 text-slate-600 hover:bg-slate-50"
              }`}
            >
              Day {dayPlan.dayNumber}
            </button>
          ))}
        </div>

        {/* Day Header */}
        <div className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                Day {currentDay.dayNumber} Focus
              </span>
              <h3 className="text-lg font-display font-semibold text-slate-950 mt-2">
                {currentDay.theme}
              </h3>
            </div>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center justify-center gap-1.5 self-start sm:self-center px-4 py-2 bg-blue-50 text-blue-600 hover:bg-blue-100 text-sm font-medium rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Activity
            </button>
          </div>

          {/* Add Activity Form */}
          {showAddForm && (
            <form onSubmit={handleAddActivitySubmit} className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-4">
              <h4 className="text-sm font-semibold text-slate-800">Add New Activity to Day {currentDay.dayNumber}</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  required
                  placeholder="Activity Title (e.g., Dinner at Chez Jean)"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <input
                  type="text"
                  placeholder="Time (e.g., 07:00 PM)"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <input
                  type="text"
                  placeholder="Duration (e.g., 2 hours)"
                  value={newDuration}
                  onChange={(e) => setNewDuration(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <input
                  type="number"
                  placeholder="Estimated Cost in USD"
                  value={newCost || ""}
                  onChange={(e) => setNewCost(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <input
                  type="text"
                  placeholder="Location/Address"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  className="w-full sm:col-span-2 px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <textarea
                  placeholder="Description or important reminders..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  rows={2}
                  className="w-full sm:col-span-2 p-3 text-sm rounded-lg border border-slate-200 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:bg-slate-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Save Activity
                </button>
              </div>
            </form>
          )}

          {/* Activities List */}
          <div className="mt-6 relative pl-6 border-l border-slate-100 space-y-6">
            {currentDay.activities.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-slate-400">No activities planned for this day.</p>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="text-xs text-blue-600 font-semibold hover:underline mt-2"
                >
                  Create one now
                </button>
              </div>
            ) : (
              currentDay.activities.map((activity, actIdx) => {
                const isExpanded = expandedActivityIndex === actIdx;
                return (
                  <div key={actIdx} className="relative group">
                    {/* Time Dot Indicator */}
                    <div className="absolute -left-9.5 top-1.5 w-7 h-7 rounded-full bg-slate-50 border-2 border-slate-200 flex items-center justify-center text-slate-600 z-10">
                      <Clock className="w-3.5 h-3.5" />
                    </div>

                    <div className={`rounded-xl border transition-all duration-200 ${
                      isExpanded 
                        ? "bg-blue-50/20 border-blue-100 shadow-sm shadow-blue-500/5" 
                        : "bg-slate-50/50 border-slate-100 hover:border-slate-200"
                    }`}>
                      {/* Activity Row Summary */}
                      <div 
                        onClick={() => setExpandedActivityIndex(isExpanded ? null : actIdx)}
                        className="flex items-center justify-between p-4 cursor-pointer"
                      >
                        <div className="flex items-start gap-3">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleActivity(actIdx);
                            }}
                            className="mt-0.5 text-slate-400 hover:text-blue-600 transition-colors"
                          >
                            {activity.completed ? (
                              <CheckCircle2 className="w-5 h-5 text-blue-600 fill-blue-50" />
                            ) : (
                              <Circle className="w-5 h-5" />
                            )}
                          </button>
                          <div>
                            <span className="text-xs font-mono font-medium text-slate-400">
                              {activity.time} • {activity.duration}
                            </span>
                            <h4 className={`text-sm font-semibold text-slate-800 ${activity.completed ? "line-through text-slate-400" : ""}`}>
                              {activity.title}
                            </h4>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {activity.cost > 0 && (
                            <span className="text-xs font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md flex items-center">
                              ${activity.cost}
                            </span>
                          )}
                          <button
                            onClick={(e) => handleDeleteActivity(actIdx, e)}
                            className="p-1 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                      </div>

                      {/* Expandable Description and Details */}
                      {isExpanded && (
                        <div className="px-4 pb-4 pt-1 border-t border-slate-100/60 text-slate-600 space-y-3">
                          {activity.location && activity.location !== "N/A" && (
                            <div className="flex items-start gap-1.5 text-xs text-slate-500">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 flex-shrink-0" />
                              <span>{activity.location}</span>
                            </div>
                          )}
                          <p className="text-xs sm:text-sm leading-relaxed text-slate-600">
                            {activity.description}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Side Utilities (Notepad, Travel Specs) */}
      <div className="space-y-6">
        {/* Quick Travel Specs */}
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2.5">
            Trip Overview
          </h3>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-0.5">
              <span className="text-slate-400 font-medium">Destination</span>
              <p className="text-slate-800 font-semibold truncate">{trip.destination}</p>
            </div>
            <div className="space-y-0.5">
              <span className="text-slate-400 font-medium">Duration</span>
              <p className="text-slate-800 font-semibold">{trip.daysCount} Days</p>
            </div>
            <div className="space-y-0.5">
              <span className="text-slate-400 font-medium">Budget Level</span>
              <p className="text-slate-800 font-semibold capitalize">{trip.budgetLevel}</p>
            </div>
            <div className="space-y-0.5">
              <span className="text-slate-400 font-medium">Best Season</span>
              <p className="text-slate-800 font-semibold truncate" title={trip.bestSeason}>
                {trip.bestSeason}
              </p>
            </div>
          </div>
        </div>

        {/* Dynamic Trip Notes */}
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm space-y-3 flex flex-col h-[280px]">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
            <FileText className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-semibold text-slate-900">
              Trip Notes & Reminders
            </h3>
          </div>
          <textarea
            className="w-full flex-grow text-sm text-slate-600 placeholder-slate-400 bg-slate-50/30 p-3 rounded-xl border border-slate-200/60 focus:outline-none focus:ring-1 focus:ring-blue-500 resize-none leading-relaxed"
            placeholder="Jot down hotel codes, reservation confirmation numbers, contact info, subway lines, or flight booking times..."
            value={trip.notes || ""}
            onChange={(e) => onUpdateNotes(e.target.value)}
          />
        </div>
      </div>
    </div>
  );
}
