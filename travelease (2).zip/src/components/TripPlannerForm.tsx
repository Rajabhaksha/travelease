import React, { useState } from "react";
import { MapPin, Calendar, Compass, DollarSign, Users, Sparkles, ArrowRight } from "lucide-react";
import { Trip } from "../types";

interface TripPlannerFormProps {
  onGenerate: (formData: any) => Promise<void>;
  isLoading: boolean;
}

export default function TripPlannerForm({ onGenerate, isLoading }: TripPlannerFormProps) {
  const [destination, setDestination] = useState("");
  const [days, setDays] = useState(3);
  const [budgetLevel, setBudgetLevel] = useState<"economy" | "mid-range" | "luxury">("mid-range");
  const [travelerType, setTravelerType] = useState<"solo" | "couple" | "family" | "friends">("solo");
  const [travelersCount, setTravelersCount] = useState(1);
  const [interests, setInterests] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim()) return;
    onGenerate({
      destination,
      days,
      budgetLevel,
      travelerType,
      travelersCount,
      interests
    });
  };

  const incrementTravelers = () => setTravelersCount(prev => Math.min(prev + 1, 12));
  const decrementTravelers = () => setTravelersCount(prev => Math.max(prev - 1, 1));

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 md:p-8 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-display font-semibold text-slate-950 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          Plan Your Next Adventure
        </h2>
        <p className="text-sm text-slate-500">
          Enter your travel details and let our AI curate an extraordinary, personalized travel itinerary tailored specifically for you.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Destination */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-slate-400" />
            Where to?
          </label>
          <div className="relative">
            <input
              type="text"
              required
              placeholder="e.g. Paris, France; Kyoto, Japan; Queenstown, NZ"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              disabled={isLoading}
              className="w-full pl-4 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50/50 disabled:opacity-60"
            />
          </div>
        </div>

        {/* Days */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center justify-between gap-1.5">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-slate-400" />
              Duration
            </span>
            <span className="text-sm font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
              {days} {days === 1 ? "day" : "days"}
            </span>
          </label>
          <div className="flex items-center gap-4 py-1.5">
            <input
              type="range"
              min="1"
              max="10"
              value={days}
              onChange={(e) => setDays(parseInt(e.target.value))}
              disabled={isLoading}
              className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-none"
            />
          </div>
        </div>

        {/* Budget */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
            <DollarSign className="w-4 h-4 text-slate-400" />
            Budget Level
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(["economy", "mid-range", "luxury"] as const).map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setBudgetLevel(level)}
                disabled={isLoading}
                className={`py-2.5 px-3 rounded-xl border text-sm font-medium capitalize transition-all duration-200 ${
                  budgetLevel === level
                    ? "bg-blue-600 border-blue-600 text-white shadow-sm shadow-blue-500/10"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
                } disabled:opacity-50`}
              >
                {level === "economy" ? "Economy" : level === "mid-range" ? "Mid-range" : "Luxury"}
              </button>
            ))}
          </div>
        </div>

        {/* Travelers */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
            <Users className="w-4 h-4 text-slate-400" />
            Who is traveling?
          </label>
          <div className="grid grid-cols-2 gap-4">
            {/* Traveler Type selection */}
            <select
              value={travelerType}
              onChange={(e) => {
                const type = e.target.value as any;
                setTravelerType(type);
                if (type === "solo") setTravelersCount(1);
                else if (type === "couple") setTravelersCount(2);
                else if (travelersCount < 2) setTravelersCount(3);
              }}
              disabled={isLoading}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50/50 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 disabled:opacity-60"
            >
              <option value="solo">Solo</option>
              <option value="couple">Couple</option>
              <option value="family">Family</option>
              <option value="friends">Friends Group</option>
            </select>

            {/* Travelers Count */}
            <div className="flex items-center justify-between border border-slate-200 rounded-xl px-2 py-1 bg-slate-50/50">
              <button
                type="button"
                onClick={decrementTravelers}
                disabled={isLoading || travelerType === "solo" || travelerType === "couple" || travelersCount <= 1}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-200/60 font-semibold disabled:opacity-30"
              >
                -
              </button>
              <span className="text-sm font-medium text-slate-800">
                {travelersCount}
              </span>
              <button
                type="button"
                onClick={incrementTravelers}
                disabled={isLoading || travelerType === "solo" || travelerType === "couple"}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-200/60 font-semibold disabled:opacity-30"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Interests & Travel Styles */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700 flex items-center gap-1.5">
          <Compass className="w-4 h-4 text-slate-400" />
          Tell us about your interests, preferences, or must-see places
        </label>
        <textarea
          rows={3}
          placeholder="e.g. coffee shops, historic architectures, beautiful hikes, museums, traditional local dining, photography hot-spots..."
          value={interests}
          onChange={(e) => setInterests(e.target.value)}
          disabled={isLoading}
          className="w-full p-4 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50/50 resize-none disabled:opacity-60 text-sm"
        />
      </div>

      <div className="pt-2">
        <button
          type="submit"
          disabled={isLoading || !destination.trim()}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm shadow-blue-500/20 hover:shadow-blue-500/30 disabled:opacity-65 cursor-pointer disabled:cursor-not-allowed group"
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
              Curating Your Dream Trip...
            </div>
          ) : (
            <>
              Let's Go! Generate Itinerary
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </>
          )}
        </button>
      </div>
    </form>
  );
}
