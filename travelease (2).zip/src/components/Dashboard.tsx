import React from "react";
import { Trip } from "../types";
import { Compass, Calendar, MapPin, Users, DollarSign, Trash2, ChevronRight, PlusCircle } from "lucide-react";

interface DashboardProps {
  trips: Trip[];
  onSelectTrip: (tripId: string) => void;
  onDeleteTrip: (tripId: string) => void;
  onStartNewTrip: () => void;
}

export default function Dashboard({ trips, onSelectTrip, onDeleteTrip, onStartNewTrip }: DashboardProps) {
  return (
    <div className="space-y-8">
      {/* Hero Banner */}
      <div className="relative rounded-3xl bg-slate-900 overflow-hidden shadow-md text-white p-8 md:p-12 flex flex-col justify-between min-h-[260px] border border-slate-850">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-700/35 to-violet-800/40 mix-blend-multiply z-0" />
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl z-0" />
        <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-violet-500/10 rounded-full blur-3xl z-0" />

        <div className="relative z-10 max-w-2xl space-y-3">
          <span className="text-xs font-mono font-semibold text-blue-300 uppercase tracking-widest bg-blue-500/10 px-3 py-1.5 rounded-full border border-blue-400/20">
            Welcome to TravelEase
          </span>
          <h1 className="text-3xl md:text-4xl font-display font-bold tracking-tight">
            Seamless travel planning, powered by intelligence.
          </h1>
          <p className="text-sm md:text-base text-slate-300 font-medium leading-relaxed">
            Generate complete day-by-day itineraries, manage travel budgets, log packing lists, and consult your own expert local guide—all in one place.
          </p>
        </div>

        <div className="relative z-10 pt-6 flex flex-wrap gap-4">
          <button
            onClick={onStartNewTrip}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-blue-600/15 cursor-pointer"
          >
            <PlusCircle className="w-5 h-5" />
            Plan a New Journey
          </button>
        </div>
      </div>

      {/* Trips Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-display font-bold text-slate-900 flex items-center gap-2">
            <Compass className="w-5 h-5 text-blue-600" />
            Your Voyages
          </h2>
          <span className="text-xs text-slate-500 font-semibold bg-slate-100 px-2.5 py-1 rounded-full">
            {trips.length} {trips.length === 1 ? "trip" : "trips"} planned
          </span>
        </div>

        {trips.length === 0 ? (
          <div className="bg-white border border-dashed border-slate-200 rounded-2xl py-16 px-4 text-center space-y-4">
            <div className="w-16 h-16 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center mx-auto border border-slate-100 shadow-inner">
              <Compass className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-semibold text-slate-800">No journeys planned yet</h3>
              <p className="text-sm text-slate-400 max-w-md mx-auto">
                Ready to explore? Tap the button below to specify your dream destination and let the AI tailor an extraordinary itinerary.
              </p>
            </div>
            <button
              onClick={onStartNewTrip}
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-850 text-white text-sm font-semibold rounded-xl transition-all cursor-pointer"
            >
              Start Planning
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trips.map((trip) => (
              <div
                key={trip.id}
                onClick={() => onSelectTrip(trip.id)}
                className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:border-slate-200 transition-all duration-200 flex flex-col justify-between overflow-hidden cursor-pointer group"
              >
                {/* Card Header & Title */}
                <div className="p-5 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded uppercase tracking-wider">
                      {trip.budgetLevel}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Are you sure you want to delete ${trip.tripName}?`)) {
                          onDeleteTrip(trip.id);
                        }
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-slate-900 leading-snug group-hover:text-blue-600 transition-colors">
                      {trip.tripName}
                    </h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                      <MapPin className="w-3.5 h-3.5 flex-shrink-0 text-slate-400" />
                      {trip.destination}
                    </p>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">
                    {trip.description}
                  </p>
                </div>

                {/* Card Bottom Specs */}
                <div className="px-5 py-4 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-semibold">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {trip.daysCount} Days
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-400" />
                      {trip.travelersCount} {trip.travelersCount === 1 ? "Traveler" : "Travelers"}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
