import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

let aiClient: GoogleGenAI | null = null;

function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing. Please configure it in your Secrets panel.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// 1. API: Generate travel itinerary
app.post("/api/itinerary", async (req, res) => {
  try {
    const { destination, days, budgetLevel, travelersCount, interests, travelerType } = req.body;

    if (!destination || !days) {
      return res.status(400).json({ error: "Destination and duration (days) are required." });
    }

    const ai = getGeminiClient();

    const prompt = `Generate a comprehensive, engaging, and detailed travel itinerary and trip plan for:
- Destination: ${destination}
- Duration: ${days} days
- Budget Level: ${budgetLevel || "mid-range"} (economy, mid-range, luxury)
- Number of Travelers: ${travelersCount || 1}
- Interests / Activities: ${interests || "general sightseeing, local food"}
- Traveler Type: ${travelerType || "solo"} (solo, couple, family, friends)

Provide creative trip names, packing lists tailored to the destination's climate/season, and detailed day-by-day activities. Every single activity should have realistic costs (in USD), times, and locations/addresses. Make the descriptions rich and informative. Make sure the total estimated budget matches the budget level.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert global travel planner and local guide. Your job is to create highly personalized, immersive, and logistically sound travel plans.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tripName: { 
              type: Type.STRING,
              description: "A creative, appealing name for the trip (e.g. 'Kyoto Zen & Tea Gardens', 'Adrenaline-Fueled Queenstown')"
            },
            destination: { type: Type.STRING },
            description: { 
              type: Type.STRING,
              description: "A beautiful introductory summary of what makes this trip special." 
            },
            bestSeason: { 
              type: Type.STRING,
              description: "The best time of year to visit this destination for this style of trip." 
            },
            packingList: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Recommended specific packing items based on the destination climate, style of travel, and activities."
            },
            budgetEstimate: {
              type: Type.OBJECT,
              properties: {
                flights: { type: Type.NUMBER, description: "Estimated flight/transit cost per traveler in USD" },
                lodging: { type: Type.NUMBER, description: "Estimated total hotel/lodging cost in USD" },
                food: { type: Type.NUMBER, description: "Estimated total food & meals cost in USD" },
                activities: { type: Type.NUMBER, description: "Estimated total activities/entry tickets cost in USD" },
                transport: { type: Type.NUMBER, description: "Estimated local transportation (taxis, subway, car rental) cost in USD" },
                misc: { type: Type.NUMBER, description: "Estimated emergency, souvenir, and miscellaneous cost in USD" }
              },
              required: ["flights", "lodging", "food", "activities", "transport", "misc"]
            },
            itinerary: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  theme: { type: Type.STRING, description: "Core focus or highlight of the day (e.g., 'Historic Temples & Traditional Bamboo Forests')" },
                  activities: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING, description: "Name of the activity or attraction" },
                        time: { type: Type.STRING, description: "Suggested start time (e.g. '09:00 AM' or '01:30 PM')" },
                        duration: { type: Type.STRING, description: "Estimated duration (e.g. '2 hours', 'Half day')" },
                        cost: { type: Type.NUMBER, description: "Estimated cost per person in USD (0 if free)" },
                        location: { type: Type.STRING, description: "Specific address, neighborhood, or venue location" },
                        description: { type: Type.STRING, description: "A rich, informative description explaining what to do, what to look out for, or insider tips." }
                      },
                      required: ["title", "time", "duration", "cost", "location", "description"]
                    }
                  }
                },
                required: ["dayNumber", "theme", "activities"]
              }
            }
          },
          required: ["tripName", "destination", "description", "bestSeason", "packingList", "budgetEstimate", "itinerary"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response text received from Gemini.");
    }

    const data = JSON.parse(text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error generating itinerary:", error);
    res.status(500).json({ 
      error: error.message || "An unexpected error occurred while generating your itinerary." 
    });
  }
});

// 2. API: Assistant Chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message, chatHistory, destination, tripContext } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are a friendly, highly knowledgeable AI Travel Assistant for the app TravelEase.
You are helping the user plan, refine, and enjoy their trip to: "${destination || "their chosen destination"}".
${tripContext ? `The current planned itinerary details are: ${JSON.stringify(tripContext)}` : ""}

Provide highly specific, practical, and localized advice. Suggest specific local restaurants, hidden gems, transport alternatives, and tips for customs, safety, and cultural etiquette.
Keep your answers beautifully formatted in clean Markdown, with concise and organized bullet points. Be enthusiastic, helpful, and objective.`;

    // Format chat history for the Gemini API chat mechanism or run generateContent
    // Since we want to handle custom messages, we can pass contents as a formatted array
    const contents: any[] = [];
    if (chatHistory && Array.isArray(chatHistory)) {
      chatHistory.forEach((msg: any) => {
        contents.push({
          role: msg.sender === "user" ? "user" : "model",
          parts: [{ text: msg.text }]
        });
      });
    }

    // Append the latest user message
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
      }
    });

    const text = response.text;
    res.json({ reply: text });
  } catch (error: any) {
    console.error("Error in travel assistant chat:", error);
    res.status(500).json({ 
      error: error.message || "An unexpected error occurred in your assistant chat." 
    });
  }
});

// Serve frontend assets
async function setupViteMiddleware() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }
}

setupViteMiddleware().then(() => {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[TravelEase Server] Running at http://localhost:${PORT}`);
  });
});
